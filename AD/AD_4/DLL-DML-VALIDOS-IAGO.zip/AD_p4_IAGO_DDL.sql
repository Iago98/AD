--------------------------------------------------------
-- Archivo creado  - viernes-febrero-07-2020   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Sequence SEQ_CICLO
--------------------------------------------------------

   CREATE SEQUENCE  "SEQ_CICLO"  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 23 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Sequence SEQ_MODULO
--------------------------------------------------------

   CREATE SEQUENCE  "SEQ_MODULO"  MINVALUE 0 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 77 CACHE 20 NOORDER  NOCYCLE  NOKEEP  NOSCALE  GLOBAL ;
--------------------------------------------------------
--  DDL for Table ALUMNO
--------------------------------------------------------

  CREATE TABLE "ALUMNO" 
   (	"DNI" VARCHAR2(9), 
	"NOMBRE" VARCHAR2(20), 
	"PRIMERAPELLIDO" VARCHAR2(20), 
	"SEGUNDOAPELLIDO" VARCHAR2(20), 
	"TELEFONO" VARCHAR2(9), 
	"FECHANACIMIENTO" DATE
   ) ;
--------------------------------------------------------
--  DDL for Table CICLO
--------------------------------------------------------

  CREATE TABLE "CICLO" 
   (	"ID" NUMBER, 
	"NOMBRE" VARCHAR2(60), 
	"NIVEL" VARCHAR2(10), 
	"CURSO" NUMBER(1,0)
   ) ;
--------------------------------------------------------
--  DDL for Table CURSA
--------------------------------------------------------

  CREATE TABLE "CURSA" 
   (	"ANHO" VARCHAR2(4), 
	"ID_MODULO" NUMBER(*,0), 
	"DNI" VARCHAR2(9), 
	"NOTA" NUMBER(4,2)
   ) ;
--------------------------------------------------------
--  DDL for Table MODULO
--------------------------------------------------------

  CREATE TABLE "MODULO" 
   (	"ID" NUMBER, 
	"NOMBRE" VARCHAR2(60), 
	"CURSO" NUMBER(1,0), 
	"HORAS" NUMBER(3,0), 
	"ID_CICLO" NUMBER
   ) ;
--------------------------------------------------------
--  DDL for Index ALUMNO_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "ALUMNO_PK" ON "ALUMNO" ("DNI") 
  ;
--------------------------------------------------------
--  DDL for Index CICLO_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "CICLO_PK" ON "CICLO" ("ID") 
  ;
--------------------------------------------------------
--  DDL for Index CURSA_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "CURSA_PK" ON "CURSA" ("DNI", "ID_MODULO") 
  ;
--------------------------------------------------------
--  DDL for Index MODULO_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "MODULO_PK" ON "MODULO" ("ID") 
  ;
